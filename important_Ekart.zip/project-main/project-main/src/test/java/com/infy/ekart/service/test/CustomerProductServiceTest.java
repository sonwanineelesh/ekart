package com.infy.ekart.service.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.entity.Product;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.service.CustomerProductService;
import com.infy.ekart.service.CustomerProductServiceImpl;

@SpringBootTest
class CustomerProductServiceTest {

	// Write testcases here
	@Mock
	private ProductRepository productRepository;
	@InjectMocks
	private CustomerProductService productService=new CustomerProductServiceImpl();
	
	@Test
	void getAllProductsValid() throws EKartException{
		List<Product> products=new ArrayList<Product>();
		Product product1=new Product();
		product1.setProductId(1);
		products.add(product1);
		Product product2=new Product();
		product2.setProductId(2);
		products.add(product2);
		Mockito.when(productRepository.findAll()).thenReturn(products);
		Assertions.assertEquals(products.size(), productService.getAllProducts().size());
	}
	@Test
	void getProductByIdValidTest() throws EKartException{
		Product product = new Product();
		product.setProductId(1234);
		Mockito.when(productRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(product));
		ProductDTO productDTO=productService.getProductById(product.getProductId());
		Assertions.assertEquals(product.getProductId(),productDTO.getProductId());
	}
	@Test
	void getproductByIdTest()throws EKartException{
		Product product = new Product();
		product.setProductId(1234);
		Mockito.when(productRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		EKartException excep=Assertions.assertThrows(EKartException.class, ()->productService.getProductById(product.getProductId()));
		Assertions.assertEquals("ProductService.PRODUCT_NOT_AVAILABLE", excep.getMessage() );
		
	}
	@Test
	public void reduceAvailableQuantityInvalidTest() {
		Product product=new Product();
		product.setProductId(1234);
		product.setAvailableQuantity(23);
		Mockito.when(productRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		EKartException excep =Assertions.assertThrows(EKartException.class, ()->productService.reduceAvailableQuantity(product.getProductId(), product.getAvailableQuantity()));
		Assertions.assertEquals("ProductService.PRODUCT_NOT_AVAILABLE", excep.getMessage());
	}
	@Test
	public void reduceAvailableQuantityValidTest() throws EKartException{
		Product product = new Product();
		product.setProductId(1000);
		product.setAvailableQuantity(1);
		
		Mockito.when(productRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(product));
		Assertions.assertDoesNotThrow(()->productService.reduceAvailableQuantity(product.getProductId(), product.getAvailableQuantity()));
				
	}

}
