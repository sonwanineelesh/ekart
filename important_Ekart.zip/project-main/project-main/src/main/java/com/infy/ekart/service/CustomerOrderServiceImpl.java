package com.infy.ekart.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.ekart.dto.CustomerDTO;
import com.infy.ekart.dto.OrderDTO;
import com.infy.ekart.dto.OrderStatus;
import com.infy.ekart.dto.OrderedProductDTO;
import com.infy.ekart.dto.PaymentThrough;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.entity.Order;
import com.infy.ekart.entity.OrderedProduct;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerOrderRepository;

//Add the missing annotation
@Service(value="customerOrderService")
@Transactional
public class CustomerOrderServiceImpl implements CustomerOrderService {
	@Autowired
	private CustomerOrderRepository orderRepository;
	@Autowired
	private CustomerService customerService;

	@Override
	public Integer placeOrder(OrderDTO orderDTO) throws EKartException {
		CustomerDTO customerDTO = customerService.getCustomerByEmailId(orderDTO.getCustomerEmailId());
		if (customerDTO.getAddress().isBlank() || customerDTO.getAddress() == null) {
			throw new EKartException("OrderService.ADDRESS_NOT_AVAILABLE");
		}

		Order order = new Order();
		order.setDeliveryAddress(customerDTO.getAddress());
		order.setCustomerEmailId(orderDTO.getCustomerEmailId());
		order.setDateOfDelivery(orderDTO.getDateOfDelivery());
		order.setDateOfOrder(LocalDateTime.now());
		order.setPaymentThrough(PaymentThrough.valueOf(orderDTO.getPaymentThrough()));
		if (order.getPaymentThrough().equals(PaymentThrough.CREDIT_CARD)) {
			order.setDiscount(10.00d);
		} else {
			order.setDiscount(5.00d);

		}

		order.setOrderStatus(OrderStatus.PLACED);
		Double price = 0.0;
		List<OrderedProduct> orderedProducts = new ArrayList<OrderedProduct>();

		for (OrderedProductDTO orderedProductDTO : orderDTO.getOrderedProducts()) {
			if (orderedProductDTO.getProduct().getAvailableQuantity() < orderedProductDTO.getQuantity()) {
				throw new EKartException("OrderService.INSUFFICIENT_STOCK");
			}

			OrderedProduct orderedProduct = new OrderedProduct();
			orderedProduct.setProductId(orderedProductDTO.getProduct().getProductId());
			orderedProduct.setQuantity(orderedProductDTO.getQuantity());
			orderedProducts.add(orderedProduct);
			price = price + orderedProductDTO.getQuantity() * orderedProductDTO.getProduct().getPrice();

		}

		order.setOrderedProducts(orderedProducts);

		order.setTotalPrice(price * (100 - order.getDiscount()) / 100);

		orderRepository.save(order);

		return order.getOrderId();
	}

	// Get the Order details by using the OrderId
	// If not found throw EKartException with message OrderService.ORDER_NOT_FOUND
	// Else return the order details along with the ordered products
	@Override
	public OrderDTO getOrderDetails(Integer orderId) throws EKartException {

		// write your logic here
		Optional<Order> optional=orderRepository.findById(orderId);
		Order order=optional.orElseThrow(()-> new EKartException("OrderService.ORDER_NOT_FOUND"));
		
		OrderDTO orderDTOs=new OrderDTO();
		orderDTOs.setCustomerEmailId(order.getCustomerEmailId());
		orderDTOs.setDateOfDelivery(order.getDateOfDelivery());
		orderDTOs.setDateOfOrder(order.getDateOfOrder());
		orderDTOs.setDeliveryAddress(order.getDeliveryAddress());
		orderDTOs.setDiscount(order.getDiscount());
		orderDTOs.setOrderId(order.getOrderId());
		orderDTOs.setOrderStatus(order.getOrderStatus().toString());
		orderDTOs.setPaymentThrough(order.getPaymentThrough().toString());
		orderDTOs.setTotalPrice(order.getTotalPrice());
		
		List<OrderedProductDTO> orderedProductList =new ArrayList<>();
		for(OrderedProduct orderedProduct : order.getOrderedProducts()) {
			OrderedProductDTO orderedProductDTO=new OrderedProductDTO();
			ProductDTO productDTO=new ProductDTO();
			productDTO.setProductId(orderedProduct.getProductId());
			orderedProductDTO.setOrderedProductId(orderedProduct.getOrderedProductId());
			orderedProductDTO.setProduct(productDTO);
			orderedProductDTO.setQuantity(orderedProduct.getQuantity());
			orderedProductList.add(orderedProductDTO);
			
		}
		orderDTOs.setOrderedProducts(orderedProductList);
		return orderDTOs;
	}

	// Get the Order details by using the OrderId
	// If not found throw EKartException with message OrderService.ORDER_NOT_FOUND
	// Else update the order status with the given order status
	@Override
	public void updateOrderStatus(Integer orderId, OrderStatus orderStatus) throws EKartException {
		// write your logic here
		Optional<Order> optional=orderRepository.findById(orderId);
		Order order=optional.orElseThrow(()->new EKartException("OrderService.ORDER_NOT_FOUND"));
		order.setOrderStatus(orderStatus);
	}

	// Get the Order details by using the OrderId
	// If not found throw EKartException with message OrderService.ORDER_NOT_FOUND
	// Else check if the order status is already confirmed, if yes then throw
	// EKartException with message OrderService.TRANSACTION_ALREADY_DONE
	// Else update the paymentThrough with the given paymentThrough option
	@Override
	public void updatePaymentThrough(Integer orderId, PaymentThrough paymentThrough) throws EKartException {

		// write your logic here
		Optional<Order> optional=orderRepository.findById(orderId);
		Order order=optional.orElseThrow(()->new EKartException("OrderService.ORDER_NOT_FOUND"));
		if(order.getOrderStatus().equals(OrderStatus.CONFIRMED))
		throw new EKartException("OrderService.TRANSACTION_ALREADY_DONE");
		order.setPaymentThrough(paymentThrough);
	}

	// Get the list of Order details by using the emailId
	// If the list is empty throw EKartException with message
	// OrderService.NO_ORDERS_FOUND
	// Else populate the order details along with ordered products and return that
	// list

	@Override
	public List<OrderDTO> findOrdersByCustomerEmailId(String emailId) throws EKartException {
		// write your logic here
		List<Order> orderList=orderRepository.findByCustomerEmailId(emailId);
		if(orderList.isEmpty())
			throw new EKartException("OrderService.NO_ORDERS_FOUND");
		List<OrderDTO> orderDTOs=new ArrayList<>();
		for(Order order:orderList) {
			OrderDTO orderdto=new OrderDTO();
			orderdto.setCustomerEmailId(order.getCustomerEmailId());
			orderdto.setDateOfDelivery(order.getDateOfDelivery());
			orderdto.setDateOfOrder(order.getDateOfOrder());
			orderdto.setDeliveryAddress(order.getDeliveryAddress());
			orderdto.setDiscount(order.getDiscount());
			orderdto.setOrderId(order.getOrderId());
			orderdto.setOrderStatus(order.getOrderStatus().toString());
			orderdto.setPaymentThrough(order.getPaymentThrough().toString());
			orderdto.setTotalPrice(order.getTotalPrice());
			
			List<OrderedProductDTO> orderedProductList=new ArrayList<>();
			for(OrderedProduct orderedProduct:order.getOrderedProducts()) {
				OrderedProductDTO orderedProductdto=new OrderedProductDTO();
				ProductDTO productDTOs=new ProductDTO();
				productDTOs.setProductId(orderedProduct.getOrderedProductId());
				orderedProductdto.setOrderedProductId(orderedProduct.getOrderedProductId());
				orderedProductdto.setQuantity(orderedProduct.getQuantity());
				orderedProductdto.setProduct(productDTOs);
				orderedProductList.add(orderedProductdto);
			}
			orderdto.setOrderedProducts(orderedProductList);
			orderdto.setDeliveryAddress(order.getDeliveryAddress());
			orderDTOs.add(orderdto);
			
			
			
		}
		return orderDTOs;
	}

}
